<?php
/**
 * Fundació Ave Maria — funcions del tema
 *
 * @package avemaria
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'AVM_VERSION', '1.0.0' );

/* ------------------------------------------------------------------
 * 1. Configuració bàsica del tema
 * ------------------------------------------------------------------ */
function avm_setup() {
	load_theme_textdomain( 'avemaria', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );

	// Logo personalitzable des de Personalitza > Identitat del lloc.
	add_theme_support( 'custom-logo', array(
		'height'      => 60,
		'width'       => 200,
		'flex-height' => true,
		'flex-width'  => true,
	) );

	// Menús editables des d'Aparença > Menús.
	register_nav_menus( array(
		'primary'      => __( 'Menú principal (capçalera)', 'avemaria' ),
		'footer-1'     => __( 'Peu — Columna Serveis', 'avemaria' ),
		'footer-2'     => __( 'Peu — Columna Col·labora', 'avemaria' ),
		'legal'        => __( 'Peu — Enllaços legals', 'avemaria' ),
	) );

	// Mida d'imatge per a fotos de targeta.
	add_image_size( 'avm-card', 720, 480, true );
}
add_action( 'after_setup_theme', 'avm_setup' );

/* ------------------------------------------------------------------
 * 2. Estils i scripts
 * ------------------------------------------------------------------ */
function avm_assets() {
	// Tipografies de marca (Montserrat + JetBrains Mono).
	wp_enqueue_style(
		'avm-fonts',
		'https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono:wght@400;500&display=swap',
		array(),
		null
	);

	// Full d'estils principal (style.css de l'arrel del tema).
	wp_enqueue_style( 'avm-style', get_stylesheet_uri(), array( 'avm-fonts' ), AVM_VERSION );

	// JavaScript (animacions d'aparició i comptadors).
	wp_enqueue_script( 'avm-theme', get_template_directory_uri() . '/assets/theme.js', array(), AVM_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'avm_assets' );

/* ------------------------------------------------------------------
 * 3. Helpers
 * ------------------------------------------------------------------ */

/**
 * Retorna un valor del Customizer.
 *
 * Si no es passa cap valor per defecte, s'agafa el del fitxer de defaults,
 * de manera que la portada es vegi plena fins i tot abans d'editar res.
 */
function avm_mod( $id, $default = null ) {
	if ( null === $default ) {
		$default = avm_def( $id );
	}
	return get_theme_mod( $id, $default );
}

/**
 * Pinta un bloc de foto: la imatge si està definida, o el rectangle gris.
 *
 * @param string $img_url  URL de la imatge (pot estar buida).
 * @param string $classes  Classes extra per al contenidor .photo.
 * @param string $label    Text que es mostra dins del rectangle gris.
 */
function avm_photo( $img_url = '', $classes = '', $label = 'Foto' ) {
	if ( $img_url ) {
		echo '<div class="photo ' . esc_attr( $classes ) . '">';
		echo '<img src="' . esc_url( $img_url ) . '" alt="">';
		echo '</div>';
	} else {
		echo '<div class="photo empty ' . esc_attr( $classes ) . '" data-label="' . esc_attr( $label ) . '"></div>';
	}
}

/**
 * Logotip de marca en SVG (s'usa com a alternativa si no s'ha pujat un logo).
 */
function avm_logo_svg() {
	return '<svg viewBox="0 0 554.59 168.37" role="img" aria-label="Fundació Ave Maria">
<defs><style>.lh1{fill:#d4859a}.lh2{fill:#f2c14e}.lh3{fill:#5dade2}.lh4{fill:#fff}.lh5{fill:#e85d75}.lh6{fill:#2d936c}.lh7{fill:#e8863a}.lhw{fill:#2c2c2c}</style></defs>
<g>
<rect class="lh4" x="43.86" y="44.29" width="76.86" height="74.21"/><rect class="lh4" width="56.12" height="56.12"/><rect class="lh2" x="56.12" width="56.12" height="56.12"/><path class="lh6" d="M112.25,0v56.12h-56.12L112.25,0Z"/><rect class="lh3" x="112.25" width="56.12" height="56.12"/><path class="lh7" d="M112.25,0v56.12h56.12L112.25,0Z"/><rect class="lh1" x="112.25" y="56.12" width="56.12" height="56.12"/><path class="lh5" d="M112.25,56.12h56.12v56.12l-56.12-56.12Z"/><rect class="lh7" y="56.12" width="56.12" height="56.12"/><path class="lh3" d="M0,84.19c0-15.5,12.56-28.06,28.06-28.06s28.06,12.56,28.06,28.06-12.56,28.06-28.06,28.06S0,99.69,0,84.19"/><rect class="lh1" x=".56" width="56.12" height="56.12"/><path class="lh2" d="M.56,56.12V0c31,0,56.12,25.13,56.12,56.12H.56Z"/><rect class="lh2" y="112.25" width="56.12" height="56.12"/><path class="lh3" d="M0,112.25h56.12L0,168.37v-56.12Z"/><rect class="lh5" x="56.12" y="112.25" width="56.12" height="56.12"/><path class="lh6" d="M56.12,112.25c15.5,0,28.06,12.56,28.06,28.06s-12.56,28.06-28.06,28.06v-56.12Z"/><rect class="lh7" x="112.25" y="112.25" width="56.12" height="56.12"/><rect class="lh3" x="112.25" y="134.7" width="56.12" height="33.67"/><rect class="lh3" x="112.2" y="112.25" width="28.06" height="28.06"/>
<g class="lhw"><path d="M226.6,39h-14.44l-2.55,6.62h-13.03l16.61-37.99h12.59l16.61,37.99h-13.24l-2.55-6.62ZM223.08,29.77l-3.69-9.55-3.69,9.55h7.38Z"/><path d="M285.22,7.63l-16.06,37.99h-12.59l-16.06-37.99h13.79l9.06,22.2,9.28-22.2h12.59Z"/><path d="M320.4,35.96v9.66h-31.59V7.63h30.88v9.66h-18.29v4.45h16.06v9.23h-16.06v4.99h19Z"/></g>
<g class="lhw"><path d="M200.43,126.46v16.23h20.24v2.5h-20.24v16.77h-2.77v-37.99h25.4v2.5h-22.63Z"/><path d="M240.54,145.83v-21.87h2.77v21.76c0,9.5,4.56,13.95,12.48,13.95s12.43-4.45,12.43-13.95v-21.76h2.77v21.87c0,10.85-5.81,16.39-15.25,16.39s-15.2-5.54-15.2-16.39Z"/><path d="M323.8,123.96v37.99h-2.28l-25.89-33v33h-2.77v-37.99h2.33l25.83,33v-33h2.77Z"/><path d="M346,123.96h15.03c12.05,0,20.19,7.92,20.19,19s-8.14,19-20.19,19h-15.03v-37.99ZM360.82,159.46c10.75,0,17.64-6.84,17.64-16.5s-6.89-16.5-17.64-16.5h-12.05v33h12.05Z"/><path d="M422.75,151.26h-22.03l-4.83,10.69h-2.99l17.48-37.99h2.77l17.48,37.99h-2.99l-4.88-10.69ZM421.72,148.93l-9.99-21.93-9.93,21.93h19.92Z"/><path d="M442.29,142.96c0-11.07,8.41-19.27,19.7-19.27,5.37,0,10.2,1.74,13.51,5.26l-1.74,1.79c-3.26-3.2-7.22-4.5-11.67-4.5-9.71,0-17.04,7.16-17.04,16.72s7.33,16.72,17.04,16.72c4.45,0,8.41-1.36,11.67-4.56l1.74,1.79c-3.31,3.53-8.14,5.32-13.51,5.32-11.29,0-19.7-8.2-19.7-19.27Z"/><path d="M493.75,123.96h2.77v37.99h-2.77v-37.99Z"/><path d="M515.08,142.96c0-11.02,8.41-19.27,19.76-19.27s19.76,8.2,19.76,19.27-8.47,19.27-19.76,19.27-19.76-8.25-19.76-19.27ZM551.77,142.96c0-9.61-7.27-16.72-16.93-16.72s-16.99,7.11-16.99,16.72,7.27,16.72,16.99,16.72,16.93-7.11,16.93-16.72ZM539.29,114.46h3.91l-8.52,6.4h-2.93l7.54-6.4Z"/></g>
<g class="lhw"><path d="M230.51,101.48l-.11-17.31-8.25,13.89h-5.64l-8.25-13.3v16.72h-11.67v-37.99h10.53l12.37,20.24,12.05-20.24h10.53l.11,37.99h-11.67Z"/><path d="M276.59,94.86h-14.44l-2.55,6.62h-13.03l16.61-37.99h12.59l16.61,37.99h-13.24l-2.55-6.62ZM273.07,85.63l-3.69-9.55-3.69,9.55h7.38Z"/><path d="M313.07,91.93h-3.47v9.55h-12.81v-37.99h18.29c10.58,0,17.31,5.54,17.31,14.33,0,5.48-2.61,9.61-7.16,11.94l7.98,11.72h-13.68l-6.46-9.55ZM314.26,73.37h-4.67v8.9h4.67c3.53,0,5.21-1.68,5.21-4.45s-1.68-4.45-5.21-4.45Z"/><path d="M339.56,63.49h12.81v37.99h-12.81v-37.99Z"/><path d="M386.78,94.86h-14.44l-2.55,6.62h-13.03l16.61-37.99h12.59l16.61,37.99h-13.24l-2.55-6.62ZM383.25,85.63l-3.69-9.55-3.69,9.55h7.38Z"/></g>
</g></svg>';
}

/**
 * Mostra el logo: el logo personalitzat si n'hi ha, o el SVG de marca.
 */
function avm_branding() {
	if ( has_custom_logo() ) {
		the_custom_logo();
	} else {
		echo '<a class="brand-link" href="' . esc_url( home_url( '/' ) ) . '" aria-label="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . avm_logo_svg() . '</a>';
	}
}

/* ------------------------------------------------------------------
 * 4. Valors per defecte i Customizer (camps editables de la portada)
 * ------------------------------------------------------------------ */
require get_template_directory() . '/inc/defaults.php';
require get_template_directory() . '/inc/customizer.php';
